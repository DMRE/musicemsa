<!--
Copyright EMSA Música 
Created By: Daniel Ramírez
Country   : GDL JAL MX
-->

<header class="main-header">
        <nav class="navbar navbar-static-top">
            <div class="navbar-top">
              <div class="container">
                  <div class="row">
                    <div class="col-sm-6 col-xs-12">
                       <ul class="list-unstyled list-inline header-contact">
                            <li> <i class="fa fa-phone"></i> <a href="tel:">+52 36-42-00-18 </a> </li>
                            <li> <i class="fa fa-envelope"></i> <a href="mailto:contacto@musicemsa.com">contacto@musicemsa.com</a> </li>
                       </ul>
                    </div>
                    <div class="col-sm-6 col-xs-12 text-right">
                        <ul class="list-unstyled list-inline header-social">
                            <li> <a href="https://www.facebook.com/EMSAEscuelademusica/"> <i class="fa fa-facebook"></i> </a> </li>
                            <li> <a href="https://www.youtube.com/channel/UCu-_2T-oM_pnjDk17oJBAEA"> <i class="fa fa-youtube"></i>  </a> </li>
                            <li> <a href="https://www.instagram.com/emsa.musica/"> <i class="fa fa fa-instagram"></i>  </a> </li>
                       </ul> 
                    </div>
                  </div>
              </div>
            </div>
            <div class="navbar-main">
              <div class="container">
                <div class="navbar-header">
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                  </button>
                  <a class="navbar-brand" href="Inicio"><img src="../../../../assets/images/emsa-logo.png" alt=""></a>
                </div>
                <div id="navbar" class="navbar-collapse collapse pull-right navbar-center">
                  <ul class="nav navbar-nav">
                    <li><a  <? echo $_SESSION["1"]; ?> href="../../../../Inicio">Inicio</a></li>
                    <li><a  <? echo $_SESSION["2"]; ?> href="../../../../Noticias">Noticias</a></li>
                    <li class="has-child"><a  <? echo $_SESSION["3"]; ?> href="#">Oferta Académica</a>
                      <ul class="submenu">
                         <li class="submenu-item"><a href="../../../../EMSA-Kids">EMSA kids</a></li>
                         <li class="submenu-item"><a href="../../../../Cursos-Especializados">Cursos especializados</a></li>
                         <li class="submenu-item"><a href="../../../../Academias-de-Instrumentos">Academias de instrumentos</a></li>
                         <li class="submenu-item"><a href="../../../../Cursos-Ingreso-a-Universidad">Preparación para ingreso a universidades</a></li>
                      </ul>
                    </li>
                    <li class="has-child"><a <? echo $_SESSION["4"]; ?> href="#">Quienes Somos</a>
                      <ul class="submenu">
                         <li class="submenu-item"><a href="../../../../Conocenos">Conócenos</a></li>
                         <li class="submenu-item"><a href="../../../../Que-nos-Identifica">¿Qué nos identifica?</a></li>
                         <li class="submenu-item"><a href="../../../../Cuerpo-Academico">Cuerpo académico</a></li>
                         <li class="submenu-item"><a href="../../../../ALAEMUS">ALAEMUS</a></li>
                         <li class="submenu-item"><a href="../../../../Rockschool">Rockschool</a></li>
                         <li class="submenu-item"><a href="../../../../ABRSM">ABRSM</a></li>
                      </ul>
                    </li>
                    <li><a <? echo $_SESSION["5"]; ?> href="../../../../Galeria">Galería</a></li>
                    <li><a <? echo $_SESSION["6"]; ?> href="../../../../Contacto">Contacto</a></li>
                  </ul>
                </div>
              </div>
            </div>
        </nav> 
    </header>