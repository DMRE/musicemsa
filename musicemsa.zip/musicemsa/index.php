<?  session_start();
	$_SESSION["1"]='class="is-active"';
	include 'php/connect.php';
	$query ="SELECT * FROM `DATA-PAGES` WHERE ID = 1";
	$meta = mysqli_fetch_array(mysqli_query($link,$query),MYSQLI_ASSOC);
	$result = mysqli_query($link,"SELECT * FROM Inicio");
    $numeroNoticias = mysqli_num_rows($result);
?>
<!DOCTYPE html>
<html class="no-js">
   <head>
      <title><? echo $meta['Titulo'] ?></title>
      <meta name="description" content="<? echo $meta['Descripcion'] ?>">
      <meta name="Keywords" content="<? echo $meta['Palabras_Clave'] ?>" />
      <? include 'php/config.html';?>
   </head>
   <body>
      <? include 'header.php'; ?>
      <!-- Carousel-->
      <div id="homeCarousel" class="carousel slide carousel-home" data-ride="carousel">
         <!-- Indicators -->
         <ol class="carousel-indicators">
            <li data-target="#homeCarousel" data-slide-to="0" class="active"></li>
            <? for($i=1;$i<$numeroNoticias;$i++){
               echo '<li data-target="#homeCarousel" data-slide-to="'.$i.'"></li>';}?> 
         </ol>
         <? mysqli_data_seek ($result, 0); $fila= mysqli_fetch_array($result);?>
         <div class="carousel-inner" role="listbox">
            <div class="item active">
            	<img  src="http://musicemsa.xp3.biz/assets/images/ALAEMUS.jpg" class="img-car hidden-xs hidden-sm img-responsive hidden-md"/>
            <img  src="http://musicemsa.xp3.biz/assets/images/ALAEMUS.jpg" class="img-car-1 hidden-xs hidden-sm img-responsive hidden-lg"/>
               <img src="assets/images/slider/<? echo $fila[3]; ?>" alt="">
               <div class="container">
                  <div class="carousel-caption">
                     <h2 class="carousel-title bounceInDown animated slow"> <? echo $fila[1]; ?></h2>
                     <h4 class="carousel-subtitle bounceInUp animated slow "> <? echo $fila[2]; ?></h4>
                     <? if($fila[5]==true){
                        echo'<a href="#" class="btn btn-lg btn-secondary hidden-xs bounceInUp animated slow" data-toggle="modal" data-target="#donateModal">'.$fila[6].'</a>';
                        } ?>
                  </div>
                  <!-- /.carousel-caption -->
               </div>
            </div>
            <!-- /.item -->
            <? 
               for($i=1;$i<$numeroNoticias;$i++){
               	mysqli_data_seek ($result, $i);
               	$fila= mysqli_fetch_array($result);
               	/*----------Print items of Carousel-----------*/
               	echo '<div class="item ">
                          			<img src="assets/images/slider/'.$fila[3].'" alt="">
                          				<div class="container">
                           					<div class="carousel-caption">
                              					<h2 class="carousel-title bounceInDown animated slow">'.$fila[1].'</h2>
                              					<h4 class="carousel-subtitle bounceInUp animated slow">'.$fila[2].'</h4>';
                              					if($fila[5]==true){
                              					echo'<a href="#" class="btn btn-lg btn-secondary hidden-xs bounceInUp animated slow" data-toggle="modal" data-target="#donateModal">'.$fila[6].'</a>';
               						}
               					echo '</div> <!-- /.carousel-caption -->
                          		 		</div>
               		   </div> <!-- /.item -->';
               }
               ?>
         </div>
         <a class="left carousel-control" href="#homeCarousel" role="button" data-slide="prev">
         <span class="fa fa-angle-left" aria-hidden="true"></span>
         <span class="sr-only">Previous</span>
         </a>
         <a class="right carousel-control" href="#homeCarousel" role="button" data-slide="next">
         <span class="fa fa-angle-right" aria-hidden="true"></span>
         <span class="sr-only">Next</span>
         </a>
      </div>
      <!-- /.carousel -->
      </div>
      <article>
      <br><br>
      <div class="main-container">
         <div class="container">
            <div class="relleno"></div>
            <div class="row fadeIn animated">
               <div class="col-md-6">
                  <br><br><br><br>
                  <div class="span6">
                     <div class="flex-video widescreen"><iframe src="https://www.youtube.com/embed/F6NnPzNpFEk" frameborder="0" allowfullscreen=""></iframe></div>
                  </div>
               </div>
               <div class="col-md-6">
                  <div class="texto-1">
                     <p><?
					    $row = mysqli_fetch_array(mysqli_query($link,"SELECT * FROM `Inicio-texto` WHERE ID = 0"),MYSQLI_ASSOC);
                        echo $row['text-1'];
                        ?></p>
                  </div>
               </div>
            </div>
            <!-- /.row -->
            <!-- Google map  -->
         </div>
         <div class="relleno"></div>
         <p class="title-style-3" style="text-align:center">Ven y conócenos</p>
         <div class="relleno"></div>
         <div class="main-container fadeIn animated">
            <div class="container">
               <div class="row">
                  <div class="col-md-7 col-sm-12 col-form">
                     <!-- Google map  -->
                     <div id="map" class="contact-map"></div>
                     <!-- Google map  -->
                  </div>
                  <div class="col-md-4 col-md-offset-1 col-contact">
                     <br><br>
                     <p class="title-style-4">Nos encontramos al interior de las instalaciones del Instituto Alpes San Javier</p>
                     <div class="contact-items">
                        <ul class="list-unstyled contact-items-list">
                        	<li class="contact-item"> <span class="contact-icon"> <i class="fa fa-facebook"></i></span> <a href="https://www.facebook.com/EMSAEscuelademusica/">EMSA</a></li>
                           <li class="contact-item"> <span class="contact-icon"> <i class="fa fa-map-marker"></i></span> Paseo del Eden 2459, Colinas de San Javier, 44660 Guadalajara, Jal.</li>
                           <li class="contact-item"> <span class="contact-icon"> <i class="fa fa-phone"></i></span> +52 36-42-00-18</li>
                           <li class="contact-item"> <span class="contact-icon"> <i class="fa fa-envelope"></i></span> contacto@musicemsa.com</li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      </div>
      </div>
      </div>
      <? include 'pie.html'; ?>
   </body>
   <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCNnmqiQ02hbNv-HW1-seinPGQ750BdpoQ&signed_in=true&language=es-mx&callback=initMap"></script>
   <script>
		function initMap() {
		  var school = {lat: 20.70649, lng: -103.40312};
		  var map = new google.maps.Map(document.getElementById('map'), {
			scaleControl: true,
			center: school,
			zoom: 15
		  });
		  var infowindow = new google.maps.InfoWindow;
		  infowindow.setContent('<b>EMSA</b>');
		  var marker = new google.maps.Marker({map: map, position: school});
		  marker.addListener('click', function() {
			infowindow.open(map, marker);
		  });
		}
    </script>    
</html>