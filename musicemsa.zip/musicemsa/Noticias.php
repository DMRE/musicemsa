<? require_once 'php/connect.php';
	session_start();
         $_SESSION["2"]='class="is-active"';
         $cantidadPorPagina = 6;
         $pagina = $_GET["pagina"];
         if(isset($pagina)){
         	if(is_numeric($pagina)){
				$consultaTodo = mysqli_query($link, "SELECT * FROM Noticias");
				$numeroRegistros = mysqli_num_rows($consultaTodo);
				$numeroPaginas = ceil($numeroRegistros/$cantidadPorPagina);
				
         		if($pagina > $numeroPaginas || $pagina < 1){
         				echo'<script type="text/javascript">
         				window.location.assign("Noticias.php");
         				</script>';
         			}
         		}
         	else{
         		echo '<script type="text/javascript">
         		window.location.assign("Noticias.php");
         		</script>';
         		}
         	}
         else{
         	$pagina=1;
			$consultaTodo = mysqli_query($link, "SELECT * FROM Noticias");
			$numeroRegistros = mysqli_num_rows($consultaTodo);
			$numeroPaginas = ceil($numeroRegistros/$cantidadPorPagina);
         	}
			$mostrarDesde = $numeroRegistros-($cantidadPorPagina*($pagina-1));
	$query ="SELECT * FROM `DATA-PAGES` WHERE ID = 2";
	$meta = mysqli_fetch_array(mysqli_query($link,$query),MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html class="no-js">
   <head>
      <title><? echo $meta['Titulo'] ?></title>
      <meta name="description" content="<? echo $meta['Descripcion'] ?>"/>
      <meta name="Keywords" content="<? echo $meta['Palabras_Clave'] ?>"/>
      <? include 'php/config.html';?>
   </head>
   <body>
      <? include 'header.php'; ?>  
      <div class="page-heading text-center">
         <div class="container zoomIn animated">
            <h1 class="page-title">Noticias</h1>
            <p class="page-description">&nbsp;</p>
         </div>
      </div>
      <div class="main-container">
         <div class="container" >
            <div class="row fadeIn animated"></div>
         </div>
      </div>
      <? $j=0; 
	  	for($i=$mostrarDesde-1;$i >= 0 && $j < $cantidadPorPagina;$i--){
         	mysqli_data_seek ($consultaTodo, $i);
         	$fila = mysqli_fetch_array($consultaTodo);
			$j++;
         	echo'<div class="container" >
         			<div class="panel panel-default">
         				<div class="panel-body notice-image">
          					<div class="media">
         						<a style="text-decoration:none" href="Noticia.php?id='.$fila[0].'">
                              	<div class="media-body">
									<p class="title-style-2" style="color:white">'.$fila[1].'</p>
								  	<p class="text-left" style="color:#d9d9d9">'.$fila[3].'<p>
                                  <p style="color:#d9d9d9">';echo substr($fila[2],0,250).' ...</p>
         						</div>
								</a>
         					</div>
         				</div>
         			</div>
         		</div>';
         	} ?>
      </div> 
      </div>
      </div>
      </div>
      <div class="text-center">
         	<ul class="pagination">
      <? 
	  for($i=1;$i<=$numeroPaginas;$i++){
		  if($i==$pagina){
			echo '<li class="page-item active"><a class="page-link" href="#">'.$i.' <span class="sr-only">(current)</span></a></li>';
			  }
		  else{
		  	echo '<li><a href="?pagina='.$i.'" data-original-title="" title="">'.$i.'</a></li>';
		  		}
		  } ?>
      		</ul>
      </div>
      <? include 'pie.html'; ?>
   </body>
</html>