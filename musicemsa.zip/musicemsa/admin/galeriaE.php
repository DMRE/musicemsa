<?php 
	require_once '../php/functions.php';
	redirectToIf(checkLog(),null,'login.php');
	require_once '../php/connect.php';
	$result = mysqli_query($link,"SELECT * FROM `DATA-PAGES` WHERE ID = '13' ");
	$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Administración Escuela de Música & Artes</title>
<? require_once '../php/configAdmin.html'; ?>
<script src="js/scripts.js"></script>
<script src="js/smartcrop.js"></script>
</head>
<body>
<div id="wrapper">
<? include 'php/Menu.php'?> 
         <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                      <div id="title-edit"><h1>Galería</h1></div>
                      <div class="relleno"></div>
                      <div class="text-center panel panel-default panel-adjust">
                        <div class="">
                          <div class="col-xs-6 col-sm-3 titles"><h3>Nombre</h3></div>
                          <div class="col-xs-6 col-sm-3 titles"><h3>Título</h3></div>
                          <div class="col-xs-6 col-sm-3 titles"><h3>Descripción</h3></div>
                          <div class="col-xs-6 col-sm-3 titles"><h3>Palabras Clave</h3></div>
                        </div>
                        <br><br><br>
                        <div>
                          <div class="col-xs-6 col-sm-3 edit" contentEditable="false"><h4><? echo $row['Titulo']; ?></h4></div>
                          <div class="col-xs-6 col-sm-3 edit" id="Titulo" contentEditable="true"><h4><? echo $row['Titulo']; ?></h4></div>
                          <div class="col-xs-6 col-sm-3 edit" id="Descripcion" contentEditable="true"><h4><? echo $row['Descripcion']; ?></h4></div>
                        </div>
                        <div class="col-xs-6 col-sm-3 edit"	id="Palabras_Clave" contentEditable="true"><h4><? echo $row['Palabras_Clave']; ?></h4></div>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-6">
                    	<div class="relleno"></div>
                        <div class="text-center"
                    		<div class="btn-group text-center" role="group" aria-label="...">
                          		<button id="Select-Photos" type="button" class="btn btn-default">Seleccionar Fotos</button>
                          		<button id="Upload-Photos"type="button" class="btn btn-default">Subir </button>
                                <div id="video-here" class="show-photos"> 
                                <div class="relleno"></div>
                                </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                    	<div class="relleno"></div>
                        <div class="text-center"
                    		<div class="btn-group text-center" role="group" aria-label="...">
                            <form>
                            	Seleccionar Fotografias:<br/> <input class="button centered" type="file" id="images-selected" multiple onchange="readFiles(this);"/><br /><br />
                            </form>
                          		
                                <div></div>
                                <div class="relleno"></div>
                                <div id="img-here" class="show-photos">
                            	</div>
                        </div>
                    </div>
                    </div>
</body>
</html>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.9.1/jquery-ui.min.js"></script>
<script type="text/javascript">

var objPhoto=null, objVideo=null;
	
$(document).ready(function(){
	$('#2').addClass('active-li');
	$('#2-5').addClass('active-li-sub');
	showData("Fotos");
	showData("Videos");
	});
$("#title-edit").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });

$('#Select-Photos, #Upload-Photos').click(function(e){
	
	});

$('#Titulo, #Descripcion, #Palabras_Clave').on('keypress',function(e){
	if(e.which==13){
		var here = $(this);
		$(this).blur();
		event.preventDefault();
		uploadData("DATA-PAGES",here,13);
	}
	else{
		if(e.which==27){
			document.execCommand('undo');
			$(this).blur();
			event.preventDefault();
			}
	}
	});
	
function uploadData($table,$to,$id){
	$toAttr = $to.attr('id');
	$text = $to.text();
	if($table!="" || $toAttr!="" || $text!="" || $id!=""){
	$.ajax({
		url:'php/saveMeta.php',
		method:'post',
		dataType:"json",
		data:{table:$table,to:$toAttr,id:$id,text:$text}
		})
		.done(function(data){
			if(data==true)
				colorizeObj($to,"#33ff33");
			else
				colorizeObj($to,"#ff3333");
			})
		.fail(function(){
				colorizeObj($to,"#ff3333");
			});
	}
	else{
		console.log("uploadData: Ha ocurrido un error, Por favor declare todas las variables para usar esta funcion.");
		colorizeObj($to,"#ff3333");
		}
	}
	
function colorizeObj($obj,$ifColor){
	$obj.animate({backgroundColor:$ifColor},50);
	$obj.animate({backgroundColor:'#ffffff'},1000);
	}
	
	var showData = function($tipo){
			if(objPhoto!=null && $tipo == "Fotos"){
				$.each(objPhoto,function(index,value){
				$('#img-here').append("<a href='assets/images/gallery/"+ value.Nombre +"' class='col-md-3 col-sm-4 gallery-item lightbox'><img src='assets/images/gallery/thumb/" + value.Nombre + "' alt=''><span class='on-hover'><span class='hover-caption'>Ver Imagen</span></span></a>");
							});
			}
			else{
				if(objVideo!=null && $tipo == "Videos"){
					$.each(objVideo,function(index,value){
						$('#img-here').append('<div class="embed-responsive embed-responsive-16by9 video-shadow"><iframe class="embed-responsive-item" src="//www.youtube.com/embed/' + value.URL + '"></iframe></div><div class="relleno"></div>');
							});
					}
				else{
					$.ajax({
				url: "../php/gallery.php",
				method: "POST",
				data: { tipo: $tipo }
					})
				.done(function(data) {
						if($tipo == "Fotos"){
						objPhoto = JSON.parse(data);
						$.each(objPhoto,function(index,value){
							$('#img-here').append("<a href='../assets/images/gallery/"+ value.Nombre +"' class='col-md-3 col-sm-4 gallery-item lightbox'><img src='../assets/images/gallery/thumb/" + value.Nombre + "' alt=''><span class='on-hover'><span class='hover-caption'>Ver Imagen</span></span></a>");
							});
						}
						else{
						objVideo = JSON.parse(data);
						console.log("despues de JSON.parse(data)");
						$.each(objVideo,function(index,value){
							$('#video-here').append('<div class="embed-responsive embed-responsive-16by9 video-shadow"><iframe class="embed-responsive-item" src="//www.youtube.com/embed/' + value.URL + '"></iframe></div>');
							});
						}
				})
				.fail(function(data){
						console.log("Ha fallado la conexion, Por favor intentelo mas tarde.");
					});
					}
				}
		};
		
		
function readFiles(input){
	var numeroArchivos = input.files.length,
		archivos = input.files, 
		thumbailConfig = {width: 300, height: 300},
		calidad = 50;
	bajarResolucion(input,calidad,thumbailConfig);
		
	/*
	
	for(var j=0;j<numeroArchivos;j++){
		names[j] = input.files[j].name;
		names[j] = names[j].substring(0,names[j].lastIndexOf("."));
		var reader = new FileReader()
		// ONLOAD INICIO
		reader.onload = function(e){
			console.log(j);
			var newSRCData = e.target.result,
				newImage = document.createElement('img');
				newImage.src = newSRCData,
				compressed = jic.compress(newImage,50,"jpg");
				imagesFull[j] = compressed;
				
				smartcrop.crop(compressed,options,function(result){
						var crop = result.topCrop,
							canvas = document.createElement('canvas'),
							ctx = canvas.getContext('2d');
						canvas.width = options.width;
						canvas.height = options.height;
						ctx.drawImage(newImage, crop.x, crop.y, crop.width, crop.height, 0, 0, canvas.width, canvas.height);
						var result_image_obj = new Image();
						var newImageData = canvas.toDataURL();
						result_image_obj.src = newImageData;
						imagesCropped[j] = result_image_obj;
						if(j == numeroArchivos){
							console.log("numarchivos + "+ numeroArchivos + "  == " + j);
							if(uploadImages(names,imagesCropped,imagesFull)){
								}
							else{
								
								}
						}
						
						});
		}
		// ONLOAD FIN
		reader.readAsDataURL(input.files[j]);
		console.log(j);
		
	}
	//console.log(imagesCropped[0] + imagesFull[0]);*/
}
var imgURL = [],j=0;

function bajarResolucion($images,$calidad,config){
	var numeroArchivos = $images.files.length,
		images = $images.files;
	
	for(i=0;i<numeroArchivos;i++){
		var file = images[i];
		readFile(file, function(e){
			var newSRCData = e.target.result,
				newImage   = document.createElement('img');
			newImage.src   = newSRCData;
			var compressed = jic.compress(newImage,50,"jpg"); //Compressed.src es el canvas.toDataURL();
			smartcrop.crop(compressed,config,function(result){
				var crop      = result.topCrop,
					canvas    = document.createElement('canvas');
				var context   = canvas.getContext('2d');
				canvas.height = config.height;
				canvas.width  = config.width;
				context.drawImage(compressed, crop.x, crop.y, crop.width, crop.height, 0, 0, canvas.width, canvas.height);
				var result_image_obj = new Image();
				result_image_obj.src = canvas.toDataURL();
				var thumbail		 = canvas.toDataURL('image/jpg');
				//$('#img-here').prepend("<a href='#' class='col-md-3 col-sm-4 gallery-item lightbox'><img src='" + thumbail + "' alt=''><span class='on-hover'><span class='hover-caption'>Ver Imagen</span></span></a>");//Esta linea será removida
				var formThumbail = base64ToBlob(thumbail,'image/jpg');
				// Crear Form
				//var formData = new FormData();
				//formData.append('thumbailBlob',tumbailBlob);
				//formData.append('imageBlob',imageBlob);
				//uploadImages(formData,function(){
					
				// 	});
				//uploadImages(compressed.src,thumbail); //Aún no esta completa
				
				});
			});
		}
	return true;
} 


function readFile(file,callback){
	var reader = new FileReader();
	reader.readAsDataURL(file);
	reader.onload = callback;
}

function uploadImages(formData,callback){
	$.ajax({
			url:'php/uploadImages.php',
			type:'POST',
			data: formData,
			
		});
	
	return true;
}
function base64ToBlob(base64, mime){
	
    mime = mime || '';
    var sliceSize = 1024;
    var byteChars = window.atob(base64);
    var byteArrays = [];

    for (var offset = 0, len = byteChars.length; offset < len; offset += sliceSize) {
        var slice = byteChars.slice(offset, offset + sliceSize);

        var byteNumbers = new Array(slice.length);
        for (var i = 0; i < slice.length; i++) {
            byteNumbers[i] = slice.charCodeAt(i);
        }

        var byteArray = new Uint8Array(byteNumbers);

        byteArrays.push(byteArray);
    }

    return new Blob(byteArrays, {type: mime});
}

</script>