<?php
	session_start();
?>
        <!-- Sidebar -->
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                   <img src="img/<? echo $_SESSION['img'] ?>" id="admin-img" /> 
                  <h4 class="text-center">Bienvenido/a<br><span id="admin-text"><? echo $_SESSION['name']; ?></span></h4>
             
                <li>
                    <a id="1" href="welcome.php">Inicio</a>
                </li>
                <li>
                    <a id="2" href="#">Editar Pagina</a>
                  <ul class="sidebar-nav-child">
                    <li><a id="2-1" href="inicioE.php">Inicio</a></li>
                    <li><a id="2-2" href="noticiasE.php">Noticias</a></li>
                    <li><a id="2-3" href="ofertaAcademicaE.php">Oferta Académica</a></li>
                    <li><a id="2-4" href="quienesSomosE.php">Quienes Somos</a></li>
                    <li><a id="2-5" href="galeriaE.php">Galeria</a></li>
                    <li><a id="2-6" href="contactoE.php">Contacto</a></li>
                  </ul>
                </li>
                <li>
                    <a id="3" href="newsletter.php">Newsletter</a>
                </li>
                <li>
                    <a id="4" href="config.php">Configuración</a>
                </li>
                <li>
                  <a id="red" href="../php/logOut.php">Salir</a>
                </li>
            </ul>
        </div>
        <!-- /#sidebar-wrapper -->