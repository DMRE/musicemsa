<?PHP
	require_once '../../php/connect.php';
	$table = $_POST['table'];
	$to = $_POST['to'];
	$id = $_POST['id'];
	$text = $_POST['text'];
	$query = "UPDATE `".$table."`  SET  `".$to."`  =  '".$text."', `changed` = 1 WHERE  `".$table."`.`ID` =".$id;
	if(mysqli_query($link,$query))
		echo true;
	else
		echo false;
?>