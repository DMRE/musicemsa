<?php 
	require_once '../php/functions.php';
	redirectToIf(checkLog(),null,'login.php');
	require_once '../php/connect.php';
	$result = mysqli_query($link,"SELECT * FROM `DATA-PAGES` WHERE ID = '1' ");
	$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Administración Escuela de Música & Artes</title>
<? require_once '../php/configAdmin.html';
?>
</head>
<body>
<div id="wrapper">
<? include 'php/Menu.php'?> 
         <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                      <div id="title-edit"><h1>Inicio</h1></div>
                      <div class="relleno"></div>
                      <div class="text-center panel panel-default panel-adjust">
                        <div class="">
                          <div class="col-xs-6 col-sm-3 titles"><h3>Nombre</h3></div>
                          <div class="col-xs-6 col-sm-3 titles"><h3>Título</h3></div>
                          <div class="col-xs-6 col-sm-3 titles"><h3>Descripción</h3></div>
                          <div class="col-xs-6 col-sm-3 titles"><h3>Palabras Clave</h3></div>
                        </div>
                        <br><br><br>
                        <div>
                          <div class="col-xs-6 col-sm-3 edit" contentEditable="false"><h4>Inicio</h4></div>
                          <div class="col-xs-6 col-sm-3 edit" id="Titulo" contentEditable="true"><h4><? echo $row['Titulo']; ?></h4></div>
                          <div class="col-xs-6 col-sm-3 edit" id="Descripcion" contentEditable="true"><h4><? echo $row['Descripcion']; ?></h4></div>
                        </div>
                        <div class="col-xs-6 col-sm-3 edit"	id="Palabras_Clave" contentEditable="true"><h4><? echo $row['Palabras_Clave']; ?></h4></div>
                        </div>
                      </div>
                    </div>
                    <div class="panel panel-default panel-adjust">
                      </div>
                </div>
            </div>
        </div>
        <!-- /#page-content-wrapper -->
    <!-- /#wrapper -->
</body>
</html>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.9.1/jquery-ui.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	$('#2').addClass('active-li');
	$('#2-1').addClass('active-li-sub');
	});
$("#title-edit").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
$('#Titulo, #Descripcion, #Palabras_Clave').on('keypress',function(e){
	if(e.which==13){
		var here = $(this);
		$(this).blur();
		event.preventDefault();
		uploadData("DATA-PAGES",here,1);
	}
	else{
		if(e.which==27){
			document.execCommand('undo');
			$(this).blur();
			event.preventDefault();
			}
	}
	});
	
function uploadData($table,$to,$id){
	$toAttr = $to.attr('id');
	$text = $to.text();
	if($table!="" || $toAttr!="" || $text!="" || $id!=""){
	$.ajax({
		url:'php/saveMeta.php',
		method:'post',
		dataType:"json",
		data:{table:$table,to:$toAttr,id:$id,text:$text}
		})
		.done(function(data){
			if(data==true)
				colorizeObj($to,"#33ff33");
			else
				colorizeObj($to,"#ff3333");
			})
		.fail(function(){
				colorizeObj($to,"#ff3333");
			});
	}
	else{
		console.log("uploadData: Ha ocurrido un error, Por favor declare todas las variables para usar esta funcion.");
		}
	}
	
function colorizeObj($obj,$ifColor){
	$obj.animate({backgroundColor:$ifColor},50);
	$obj.animate({backgroundColor:'#ffffff'},1000);
	}
</script>