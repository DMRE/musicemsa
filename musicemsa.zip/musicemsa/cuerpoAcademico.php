 <?
      session_start();
      $_SESSION["4"]='class="is-active"';
      include 'php/connect.php';
	  $consultaTodo = mysqli_query($link, "SELECT * FROM `Cuerpo-Academico`");
	  $numeroRegistros = mysqli_num_rows($consultaTodo);
	  $query ="SELECT * FROM `DATA-PAGES` WHERE ID = 9";
	  $meta = mysqli_fetch_array(mysqli_query($link,$query),MYSQLI_ASSOC);
      ?>
<!DOCTYPE html>
<html class="no-js">
   <head>
      <title><? echo $meta['Titulo'] ?></title>
      <meta name="description" content="<? echo $meta['Descripcion'] ?>">
      <meta name="Keywords" content="<? echo $meta['Palabras_Clave'] ?>" />
      <? include 'php/config.html';?>
   </head>
   <body>
   <? include 'header.php'; ?>
      <div class="main-containter">
         <div class="container">
            <div class="row">
               <br><br>
               <h1 class="text-center" style="font-weight:lighter; font-size:50px">Cuerpo Académico</h1>
            </div>
            <div class="relleno"></div>
         </div>
         <div class="container body-pannel-white-full">
         
            <?
			for($i=0;$i<$numeroRegistros;$i++){
			mysqli_data_seek ($consultaTodo, $i);
         	$fila = mysqli_fetch_array($consultaTodo);
			echo'<a href="staff.php?id='.$fila[0].'" class="col-md-3 col-sm-4 gallery-item lightbox">
						<img src="assets/images/cuerpo-academico/'.$fila[5].'" alt="">
						<span class="on-hover">
							<span class="hover-caption">'.$fila[1].' '.$fila[2].'</span>
						</span>
					</a>';
			}
            ?>
      </div>
      <div class="relleno"></div>
      <? include 'pie.html'; ?>
   </body>
</html>