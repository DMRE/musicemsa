<? include 'php/connect.php';
	$query ="SELECT * FROM `DATA-PAGES` WHERE ID = 4";
	$meta = mysqli_fetch_array(mysqli_query($link,$query),MYSQLI_ASSOC);
	session_start();
    $_SESSION["3"]='class="is-active"';
?>
<!DOCTYPE html>
<html class="no-js">
   <head>
      <title><? echo $meta['Titulo'] ?></title>
      <meta name="description" content="<? echo $meta['Descripcion'] ?>">
      <meta name="Keywords" content="<? echo $meta['Palabras_Clave'] ?>" />
      <? include 'php/config.html';?>
   </head>
   <body>
   <? include 'header.php'; ?>
  	<div class="main-containter">
         <div id="fixed-background-color"></div>
         <img id="fixed-background" src="http://musicemsa.xp3.biz/assets/images/instruments/background.jpg" />
         <div class="container">
            <div class="row">
               <div class="relleno"></div>
               <h1 class="title-white-h1">Cursos Especializados</h1>
               <div class="relleno"></div>
            </div>
         </div>
         <div class="container body-pannel-white-full">
            <div class="row">
            <div class="relleno"></div>
              <div class="text-center">
                <div class="col-md-4">
                  <div id="teatroMusical" class ="title-course">
                    <h3>Teatro Musical</h3>
                  </div>
              </div>
                <div id="teatroMusicalT1" class="hidden-md	hidden-lg info-toggle-mobile hide">
                      <p class="texto-1">¿Porqué estudiar Teatro Musical?<br><br>
 
 Actualmente la demanda de actores que sepan cantar muy bien, actuar y bailar es cada vez mayor. La Ciudad de México se esta convirtiendo en una metrópoli del teatro musical en el país y  hay una mayor búsqueda de talentos desde  edades tempranas.
 <br><br>
La EMSA a pesar de que años anteriores solo se ha enfocado al estudio de la música, nos hemos visto involucrados ya en la preparación de varios alumnos para musicales en Guadalajara y en la Ciudad de México,  que han sido escogidos, en su mayoría como protagonistas, por la preparación vocal  que han  demostrado,  por ello estamos ofertando a partir de este nuevo año escolar  el   primer curso  de Teatro Musical el cual comprende  danza, actuación, canto individual, canto colectivo y lectura musical (solfeo),  además del montaje de fragmentos de musicales clásicos,  para la presentación a exámenes de la Rockschool,  institución  británica examinadora  que ofrece certificación   hasta el nivel de licenciatura.
 <br><br>
El inicio del curso será a partir de septiembre 2016</p>
                </div>
              <div class="col-md-4">
                <div id="songWriting" class ="title-course" style="background-image: url('http://guitarlessonsinwimbledon.co.uk/wp-content/uploads/2012/01/songwriting-course-london.jpg');">
                <h3>Song writing </h3>
                  </div>
              </div>
                <div id="songWritingT1" class="hidden-md	hidden-lg info-toggle-mobile hide">
                      <p class="texto-1">Duración de 3 meses con una frecuencia semanal de 2 horas.  Aprenderás las  herramientas  básicas para crear tus propias canciones. Inicio: Enero 2017.</p>
                </div>
              <div class="col-md-4">
                <div id="armoniaContemporanea" class ="title-course" style="background-image:url('https://udemy-images.udemy.com/course/750x422/217902_d460_2.jpg');">
                <h3>Armonía contemporánea</h3>
                </div>
                <div id="armoniaContemporaneaT1" class="hidden-md	hidden-lg info-toggle-mobile hide">
                      <p class="texto-1">Duración: 3 meses con una frecuencia semanal de 2 horas. Este curso tendrá una base práctica en donde el alumno por medio de un  instrumento armónico en cada clase,  ejecutará  lo  aprendido como  conocimiento  teórico de la armonía empleada en el jazz y otros géneros de la música popular. Está dirigido a músicos en general.<br><br> Inicio: Septiembre 2016</p>
                    </div>
              </div>
                
                <div class="col-md-12 hidden-sm hidden-xs" id="info-toggle">
                  <div class="relleno"></div>
                  
                  <!-- Teatro Musical -->
                    <div id="teatroMusicalT" class="hide">
                      <h2>Teatro Musical</h2><br>
                      <p class="texto-1">¿Porqué estudiar Teatro Musical?<br><br>
 
 Actualmente la demanda de actores que sepan cantar muy bien, actuar y bailar es cada vez mayor. La Ciudad de México se esta convirtiendo en una metrópoli del teatro musical en el país y  hay una mayor búsqueda de talentos desde  edades tempranas.
 <br><br>
La EMSA a pesar de que años anteriores solo se ha enfocado al estudio de la música, nos hemos visto involucrados ya en la preparación de varios alumnos para musicales en Guadalajara y en la Ciudad de México,  que han sido escogidos, en su mayoría como protagonistas, por la preparación vocal  que han  demostrado,  por ello estamos ofertando a partir de este nuevo año escolar  el   primer curso  de Teatro Musical el cual comprende  danza, actuación, canto individual, canto colectivo y lectura musical (solfeo),  además del montaje de fragmentos de musicales clásicos,  para la presentación a exámenes de la Rockschool,  institución  británica examinadora  que ofrece certificación   hasta el nivel de licenciatura.
 <br><br>
El inicio del curso será a partir de septiembre 2016</p>
                    </div>
                  <!-- Teatro Musical -->
                  
                  <!-- Song Writing -->
                  <div id="songWritingT" class="hide">
                      <h2>Song Writing</h2><br>
                      <p class="texto-1">Duración de 3 meses con una frecuencia semanal de 2 horas.  Aprenderás las  herramientas  básicas para crear tus propias canciones. Inicio: Enero 2017.</p>
                    </div>
                  <!-- Song Writing -->
                  
                  <!-- Armonia Contemporanea -->
                  <div id="armoniaContemporaneaT" class="hide">
                      <h2>Armonía contemporánea</h2><br>
                      <p class="texto-1">Duración: 3 meses con una frecuencia semanal de 2 horas. Este curso tendrá una base práctica en donde el alumno por medio de un  instrumento armónico en cada clase,  ejecutará  lo  aprendido como  conocimiento  teórico de la armonía empleada en el jazz y otros géneros de la música popular. Está dirigido a músicos en general.<br><br> Inicio: Septiembre 2016</p>
                    </div>
                  <!-- Armonia Contemporanea -->
                  
                  <!-- Adiestramiento auditivo y lectura -->
                  <div id="adiestramientoAuditivoT" class="hide">
                      <h2>Adiestramiento auditivo y lectura</h2><br>
                      <p class="texto-1">Duración 4 meses. Una frecuencia semanal de 2 horas.  Curso intensivo de lectura y adiestramiento auditivo para estudiantes de música. <br><br>Inicio: septiembre 2016</p>
                    </div>
                  <!-- Adiestramiento auditivo y lectura -->
                  
                  <!-- Técnicas -->
                  <div id="tecnicasDeDireccionT" class="hide">
                      <h2>Técnicas de dirección coral y orquestal</h2><br>
                      <p class="texto-1">Duración 6 meses. Una frecuencia semanal de 3 horas. En este curso intensivo de dirección el alumno conocerá y aplicará los esquemas de los diferentes compases y  trabajará en el análisis necesario de las obras para su montaje. Está dirigido a  estudiantes de música y maestros de música de escuelas. <br><br>Inicio Enero 2017</p>
                    </div>
                  <!-- Técnicas -->
                  
                  <div id="button-active" class="centered-all hide">
                       <button type="button" class="btn btn-info">Solicitar Información</button>
                       </div>
                  
                  <div class="relleno"></div>
                </div>
                
              <div class="col-md-6">
                <div id="adiestramientoAuditivo" class ="title-course">
                <h3>Adiestramiento auditivo y lectura</h3>
                  </div>
                <div id="adiestramientoAuditivoT1" class="hidden-md	hidden-lg info-toggle-mobile hide">
                     <p class="texto-1">Duración 4 meses. Una frecuencia semanal de 2 horas.  Curso intensivo de lectura y adiestramiento auditivo para estudiantes de música. <br><br>Inicio: septiembre 2016</p>
                    </div>
              </div>
                <div class="col-md-6">
                  <div id="tecnicasDeDireccion" class ="title-course" style="background-image:url('http://musica.utalca.cl/imagenes/coro_utal.jpg');">
                <h3>Técnicas de dirección coral y orquestal</h3>
                  </div>
                  <div id="tecnicasDeDireccionT1" class="hidden-md	hidden-lg info-toggle-mobile hide">
                     <p class="texto-1">Duración 6 meses. Una frecuencia semanal de 3 horas. En este curso intensivo de dirección el alumno conocerá y aplicará los esquemas de los diferentes compases y  trabajará en el análisis necesario de las obras para su montaje. Está dirigido a  estudiantes de música y maestros de música de escuelas. <br><br>Inicio Enero 2017</p>
                    </div>
              </div>
                
              </div>
               </div>
           
              <!--TERMINA-->
              <div class="relleno"></div>
           <br><br>
         </div>
      </div>
      
    <? include 'pie.html'; ?>
   </body>
   <script type="text/javascript">
   var toggled = false, on = "", on1 = "";

$(document).ready(function(){
  $('#info-toggle').toggle();
});

$('#teatroMusical, #songWriting, #armoniaContemporanea, #adiestramientoAuditivo, #tecnicasDeDireccion').click(function(){
  if(toggled==true){
    $('#info-toggle').slideToggle(1000);
    $('#info-toggle-mobile').slideToggle(1000);
    $('#button-active').addClass("hide");
    $('#button-active1').addClass("hide");
    $(on).addClass("hide");
    $(on1).addClass("hide");
    toggled=false;
  }
  else{
    $(on = '#' + $(this).attr('id') + 'T').removeClass("hide");
    $(on1 = '#' + $(this).attr('id') + 'T1').removeClass("hide");
    $('#button-active').removeClass("hide");
    $('#button-active1').removeClass("hide");
    $('#info-toggle').slideToggle(1000);
    $('#info-toggle-mobile').slideToggle(1000);
    $('html,body').animate({
        scrollTop: $(on).offset().top},
        'slow');
     toggled = true;
  }
   
});
   </script>
</html>