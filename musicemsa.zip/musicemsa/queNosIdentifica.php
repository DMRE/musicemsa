<? session_start();
   $_SESSION["4"]='class="is-active"';
   include 'php/connect.php';
   $query ="SELECT * FROM `DATA-PAGES` WHERE ID = 8";
   $meta = mysqli_fetch_array(mysqli_query($link,$query),MYSQLI_ASSOC);
   		?>
<!DOCTYPE html>
<html class="no-js">
   <head>
      <title><? echo $meta['Titulo'] ?></title>
      <meta name="description" content="<? echo $meta['Descripcion'] ?>">
      <meta name="Keywords" content="<? echo $meta['Palabras_Clave'] ?>" />
      <? include 'php/config.html';?>
   </head>
   <body>
   <? include 'header.php'; ?>
   <div class="main-containter">
         <div class="container">
         </div>
         <div class="container body-pannel-white-full">
           <div class="relleno"></div>
            <div class="row text-center margin-body-pannel-full">
            <h2>Qué nos identifica</h2><br><br>
                <p class="texto-1">El cuerpo docente, las metodologías empleadas y los programas con la que cuenta la EMSA es lo que nos identifica y nos distingue de otros centros de estudios musicales. <br><br>Todos los maestros están altamente preparados, son músicos activos y profesores con experiencia tanto con niños pequeños como jóvenes, que es a quienes dirigimos esta institución. <br><br>
Los programas están todos probados con resultados excelentes siempre y cuando se establezca la disciplina de entrenamiento individual que requiere el estudio de un instrumento musical y la formación de un verdadero artista,  todo ello apegado a los valores primordiales del individuo y fomentando el amor por la música y el desarrollo de la sensibilidad y la espiritualidad.  </p>
              <div class="relleno"></div>
         </div>
      </div>
      <div class="relleno"></div>
      <div class="relleno"></div>
      <br><br><br><br>
    <? include 'pie.html'; ?>
   </body>
</html>