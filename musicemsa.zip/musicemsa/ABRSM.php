<? session_start();
   $_SESSION["4"]='class="is-active"';
   include 'php/connect.php';
   $query ="SELECT * FROM `DATA-PAGES` WHERE ID = 1";
   $meta = mysqli_fetch_array(mysqli_query($link,$query),MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html class="no-js">
   <head>
      <title><? echo $meta['Titulo'] ?></title>
      <meta name="description" content="<? echo $meta['Descripcion'] ?>">
      <meta name="Keywords" content="<? echo $meta['Palabras_Clave'] ?>" />
      <? include 'php/config.html';?>
   </head>
   <body>
   <? include 'header.php'; ?>
   <div class="main-containter">
         <div class="container">
         </div>
         <div class="container body-pannel-white-full">
           <div class="relleno"></div>
            <div class="row text-center margin-body-pannel-full">
                <img class="img-responsive img-center" src="assets/images/abrsm.png" /><br><br>
                <p class="texto-1">Associated Board of the Royal Schools of Music, es una institución examinadora  de música  que cuenta con más  de 100 años de experiencia, tiene una  presencia en mas de 90 países y cuenta con el respaldo de cuatro de los Conservatorios más importantes del Reino Unido. <br><br>
El objetivo de todas  sus  actividades es motivar y animar a alumnos y estudiantes de todos los niveles. <br><br> El ABRSM pretende fomentar el disfrute y el progreso musical a través del éxito, promover y mejorar la calidad de la enseñanza y el aprendizaje de la música. <br><br>En el ABRSM están comprometidos con la excelencia, la calidad y la innovación en el ámbito de la educación musical y con la satisfacción de las necesidades de los educadores musicales de todo el mundo, así como de sus alumnos. <br><br>
 
Para mayor información acerca de ABRSM remítase a <a href="www.abrsm.org">www.abrsm.org</a></p>
              <div class="relleno"></div>
         </div>
      </div>
    <? include 'pie.html'; ?>
   </body>
</html>