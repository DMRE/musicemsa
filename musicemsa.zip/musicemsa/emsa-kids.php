<? include 'php/connect.php';
	$query ="SELECT * FROM `DATA-PAGES` WHERE ID = 3";
	$meta = mysqli_fetch_array(mysqli_query($link,$query),MYSQLI_ASSOC);
	session_start();
    $_SESSION["3"]='class="is-active"';
	$sql_query = "SELECT * FROM `EMSA-KIDS`";
	$result=mysqli_query($link,$sql_query);
	$row=mysqli_fetch_array($result,MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html class="no-js">
   <head>
      <title><? echo $meta['Titulo'] ?></title>
      <meta name="description" content="<? echo $meta['Descripcion'] ?>">
      <meta name="Keywords" content="<? echo $meta['Palabras_Clave'] ?>" />
      <? include 'php/config.html';?>
   </head>
   <body>
   <? include 'header.php'; ?>
   <div class="main-containter">
         <div id="fixed-background-color"></div>
         <img id="fixed-background" src="https://k61.kn3.net/D/F/2/5/C/A/8B9.jpg" />
         <div class="container">
            <div class="row">
               <div class="relleno"></div>
               <h1 class="title-white-h1">EMSA KIDS</h1>
               <div class="relleno"></div>
            </div>
         </div>
         <div class="container body-pannel-white-full">
           <div class="row">
           		<div class="relleno"></div>
           			<div class="texto-1">
           				<p > <? echo $row["Text"] ?> </p>
           			</div>
           			<div class="relleno"></div>
         		</div>
      		</div>
         </div>
    <? include 'pie.html'; ?>
   </body>
</html>