<!DOCTYPE html>
<html class="no-js">
<!-- Parte logica para redirecciónar en caso de que sea otra pagina -->
      <?
         session_start();
         $_SESSION["3"]='class="is-active"';
         include 'header.php';
		 include 'php/connect.php';
   		?>
   <head>
      <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
      	<title>Oferta Académica | EMSA </title>
          <meta name="viewport" content="width=device-width, initial-scale=1">
          <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
          <link href='http://fonts.googleapis.com/css?family=Dosis:400,700' rel='stylesheet' type='text/css'>
          <link rel="shortcut icon" href="assets/images/icons/favico.png">
          <link rel="stylesheet" href="assets/css/bootstrap.min.css">
          <link rel="stylesheet" href="assets/css/font-awesome.min.css">
          <link rel="stylesheet" href="assets/css/style.css">
          <script src="assets/js/modernizr-2.6.2.min.js"></script>
   </head>
   <body>
   
               
      <!-- Java -->
      <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
      <script>window.jQuery || document.write('<script src="assets/js/jquery-1.11.1.min.js"><\/script>')</script>
      <script src="assets/js/bootstrap.min.js"></script>
      <script src="assets/js/main.js"></script>
    <? include 'pie.html'; ?>
   </body>
</html>