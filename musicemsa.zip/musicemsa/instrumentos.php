<?
	session_start();
	$_SESSION["3"]='class="is-active"';
    include 'php/connect.php';
	$query ="SELECT * FROM `DATA-PAGES` WHERE ID = 5";
	$meta = mysqli_fetch_array(mysqli_query($link,$query),MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html class="no-js">
   <head>
      <title><? echo $meta['Titulo'] ?></title>
      <meta name="description" content="<? echo $meta['Descripcion'] ?>">
      <meta name="Keywords" content="<? echo $meta['Palabras_Clave'] ?>" />
      <? include 'php/config.html';?>
   </head>
   <body>
   <? include 'header.php'; ?>
   <div class="main-containter">
         <div id="fixed-background-color"></div>
         <img id="fixed-background" src="http://musicemsa.xp3.biz/assets/images/instruments/background.jpg" />
         <div class="container">
            <div class="row">
               <br><br>
               <h1 class="text-center" style="color:white; font-weight:lighter; font-size:70px">INSTRUMENTOS</h1>
               <br>
               <div class="container">
                  <figure class="centered">
                     <img id="tronco-comun" class="instrument-icon" src="http://musicemsa.xp3.biz/assets/images/icons/three.png">
                     <img id="violin" class="instrument-icon" src="http://musicemsa.xp3.biz/assets/images/icons/violin.png">
                     <img id="piano" class="instrument-icon" src="http://musicemsa.xp3.biz/assets/images/icons/piano.png">
                     <img id="canto" class="instrument-icon" src="http://musicemsa.xp3.biz/assets/images/icons/canto.png">
                     <img id="guitarra" class="instrument-icon" src="http://musicemsa.xp3.biz/assets/images/icons/guitarra.png">
                     <img id="bateria" class="instrument-icon" src="http://musicemsa.xp3.biz/assets/images/icons/bateria.png">
                  </figure>
                  <br><br>>
               </div>
            </div>
         </div>
         <div class="container body-pannel-white-full">
            <div class="row">
              <!--COMIENZA-->
               <div id="tronco-comunT">
                  <div class="col-md-6">
                     <div id="text-margin-left" >
                        <div id="row">
                           <h1 class="text-center">Tronco Común</h1>
                        </div>
                        <img class="img-responsive img-centered-horizontal hidden-lg hidden-md" src="http://musicemsa.xp3.biz/assets/images/instruments/tronco.png"/>
                        <div class="texto-1">
                           <br><br>
                           <p>La EMSA cuenta con diferentes programas según el interés que tengas como perfil de egreso. Si deseas solo curso de instrumento o canto individual o una formación mas integral, nosotros creamos los planes para ti.<br><br> El tronco común para todas las carreras ya sea en la modalidad de música clásica o popular incluye lectura, teoría y adiestramiento auditivo, practica grupal vocal e instrumental y por supuesto la clase individual del instrumento escogido.<br><br> El ingreso puede ser cuando tú lo decidas y te comprometas. Contamos con talleres de actuación y danza que pueden complementar tu formación como artista.
                           </p>
                        </div>
                     </div>
                  </div>
                 <div id="img-margin-right" class=" hidden-xs hidden-sm ">
                     <div>
                        <img class="img-responsive" src="http://musicemsa.xp3.biz/assets/images/instruments/tronco.png"/>
                     </div>
                  </div>
               </div>
               <!--TERMINA-->
              <DIV CLASS="relleno"></DIV>
               <!--COMIENZA-->
               <div id="violinT">
                  <div class="col-md-6 hidden-xs hidden-sm">
                     <!---AQUI VA LA 1ER COLUMNA---->
                     <div>
                        <img id="violin"class="img-responsive" src="http://musicemsa.xp3.biz/assets/images/instruments/violin1.png"/>
                     </div>
                     <!---TERMINA LA PRIMERA COLUMNA--->
                  </div>
                  <div class="col-md-6">
                     <!---AQUI VA LA 2DA COLUMAN--->
                     <div id="text-margin-right" >
                        <div id="row">
                           <h1 class="text-center">Violín</h1>
                        </div>
                        <img id="violin" class="img-responsive img-centered-horizontal hidden-lg hidden-md" src="http://musicemsa.xp3.biz/assets/images/instruments/violin1.png"/>
                        <div class="texto-1">
                           <br><br>
                           <p>Dependiendo de lo que sea de tu interés y la edad con la que se inicie, la EMSA ofrece la metodología Suzuki con maestro certificado, larga experiencia y resultados, con la opción de certificarse presentando libros terminados de cada nivel en los congresos Suzuki.<br><br>
                             Programas de la Royal School of Music, probados en todas partes del mundo con gran prestigio y con posibilidades de certificarte, por medio de examen teórico dentro de la EMSA y práctico en una primera etapa en la Ciudad de México, con maestros provenientes de Inglaterra. También diseñamos programas individuales para el nivel que desees manejar de acuerdo al tiempo e interés.</p>
                        </div>
                       <div class="centered-all">
                       <button type="button" class="btn btn-info">Solicitar Información</button>
                       </div>
                     </div>
                     <!--TERMINA LA SEGUNA COLUMNA-->
                  </div>
               </div>
            </div>
           <!--TERMINA-->
           <DIV CLASS="relleno"></DIV>
           <!--COMIENZA-->
           <div class="row" id="pianoT">
                  <div class="col-md-6">
                     <div id="text-margin-left" >
                        <div id="row">
                           <h1 class="text-center">Piano</h1>
                        </div>
                        <img class="img-responsive img-centered-horizontal hidden-lg hidden-md" src="http://musicemsa.xp3.biz/assets/images/instruments/piano.png"/>
                        <div class="texto-1">
                           <br><br>
                           <p>La metodología y técnica empleada en el caso del piano, es una combinación de métodos franceses, rusos y la interpretación de las piezas y obras del repertorio pianístico del mundo de diferentes estilos y géneros.<br><br> 
                           Contamos, en la modalidad de piano clásico, la opción del programa de la Royal School Music para certicación por medio de examen en la CDMEX en una primera etapa a nivel práctico. En el caso de los pianistas populares tiene una base técnica importante, que les permitará tocar con agilidad y control de ambas manos, se les ofrecen tambien herramientas para la improvisación y el acompañamiento armónico según el género.</p>
                        </div>
                       <div class="centered-all">
                       <button type="button" class="btn btn-info">Solicitar Información</button>
                       </div>
                     </div>
                  </div>
                 <div id="img-margin-right" class=" hidden-xs hidden-sm ">
                     <div>
                        <img class="img-responsive" src="http://musicemsa.xp3.biz/assets/images/instruments/piano.png"/>
                     </div>
                  </div>
               </div>
               <!--TERMINA-->
           <div class="relleno"></div>
               <!--COMIENZA-->
           <div class="row" id="guitarraT">
                  <div class="col-md-6 hidden-xs hidden-sm" >
                     <!---AQUI VA LA 1ER COLUMNA---->
                     <div>
                        <img id="guitarra"class="img-responsive" src="http://musicemsa.xp3.biz/assets/images/instruments/guitarra.png"/>
                     </div>
                     <!---TERMINA LA PRIMERA COLUMNA--->
                  </div>
                  <div class="col-md-6">
                     <!---AQUI VA LA 2DA COLUMAN--->
                     <div id="text-margin-right" >
                        <div id="row">
                           <h1 class="text-center">Guitarra Acústica y Electrica</h1>
                        </div>
                        <img id="violin" class="img-responsive img-centered-horizontal hidden-lg hidden-md" src="http://musicemsa.xp3.biz/assets/images/instruments/guitarra.png"/>
                        <div class="texto-1">
                           <br><br>
                           <p> En el estudio de la guitarra se emplean varios métodos para el  desarrollo técnico y repertorio.  De acuerdo al grado de interés, al igual que los otros instrumentos,  podrás aprender a tocar tanto repertorio clásico como popular, en el caso de la guitarra acústica, y desarrollar habilidades  técnicas en ambas manos,  además de  recursos para improvisación y acompañamiento según el género. <br><br>  
En la modalidad de música popular implementamos el programa de Rockschool el cual puede certificarlo por medio de examen si así lo desea.
                           </p>
                        </div>
                       <div class="centered-all">
                       <button type="button" class="btn btn-info">Solicitar Información</button>
                       </div>
                     </div>
                     <!--TERMINA LA SEGUNA COLUMNA-->
                  </div>
               </div>
              <!--TERMINA-->
              
              <DIV CLASS="relleno"></DIV>
           <!--COMIENZA-->
           <div class="row" id="cantoT">
                  <div class="col-md-6">
                     <div id="text-margin-left" >
                        <div id="row">
                           <h1 class="text-center">Canto</h1>
                        </div>
                        <img class="img-responsive img-centered-horizontal hidden-lg hidden-md" src="http://musicemsa.xp3.biz/assets/images/instruments/microfono.png"/>
                        <div class="texto-1">
                           <br><br>
                           <p>En el área de Canto, el sistema de aprendizaje esta enfocado, en estos momentos, solo en la vertiente del canto contemporáneo, no lírico. <br><br>
 
Se trabaja la técnica básica del canto, dando un gran enfoque hacia la correcta respiración, que es la base de un buen cantante y vocalizaciones encaminadas a aumentar la tesitura y trabajar en la belleza del timbre de cada cantante respetando siempre su estilo o en su caso apoyando a crear su propio estilo.  
 
Al igual que en la academia de guitarra y bateria puedes certificar tus estudios por medio de examenes en los diferentes niveles que manejan Rockschool.  <br><br>
 Según la edad e interés complementamos el estudio con varios métodos para desarrollar habilidades para improvisar, scat y otros recursos propios de los diferentes géneros  populares. </p>

                        </div>
                       <div class="centered-all">
                       <button type="button" class="btn btn-info">Solicitar Información</button>
                       </div>
                     </div>
                  </div>
                 <div id="img-margin-right" class=" hidden-xs hidden-sm ">
                     <div>
                        <img class="img-responsive" src="http://musicemsa.xp3.biz/assets/images/instruments/microfono.png"/>
                     </div>
                  </div>
               </div>
               <!--TERMINA-->
               <DIV CLASS="relleno"></DIV>
               <!--COMIENZA-->
           <div class="row" id="bateriaT">
                  <div class="col-md-6 hidden-xs hidden-sm" >
                     <!---AQUI VA LA 1ER COLUMNA---->
                     <div>
                        <img id="bateria"class="img-responsive" src="http://musicemsa.xp3.biz/assets/images/instruments/bateria.png"/>
                     </div>
                     <!---TERMINA LA PRIMERA COLUMNA--->
                  </div>
                  <div class="col-md-6">
                     <!---AQUI VA LA 2DA COLUMAN--->
                     <div id="text-margin-right" >
                        <div id="row">
                           <h1 class="text-center">Batería</h1>
                        </div>
                        <img id="violin" class="img-responsive img-centered-horizontal hidden-lg hidden-md" src="http://musicemsa.xp3.biz/assets/images/instruments/bateria.png"/>
                       <div class="texto-1">
                           <br><br>
                          <p>El Programa de aprendizaje de Batería tiene como objetivo lograr que el estudiante sea capaz de dominar la forma de interpretación, técnica e improvisación de la bateria.<br><br>También a medida que avance el estudiante se le incorporara el aprendizaje de la lectura de partituras específicas de percusión. El sistema de aprendizaje estará dividido en su inicio en tres etapas.</p>
                        </div>
                       <div class="centered-all">
                       <button type="button" class="btn btn-info">Solicitar Información</button>
                       </div>
                     </div>
                     <!--TERMINA LA SEGUNA COLUMNA-->
                  </div>
               </div>
              <!--TERMINA-->
              <div class="relleno"></div>
         </div>
      </div>
    <? include 'pie.html'; ?>
   </body>
</html>
<script type="text/javascript">
	$('#bateria,#canto,#guitarra,#piano,#tronco-comun,#violin').on('click',function(){
		var on = '#' + $(this).attr('id') + 'T';
		$('html,body').animate({
        scrollTop: $(on).offset().top},
        'slow');
		});
</script>