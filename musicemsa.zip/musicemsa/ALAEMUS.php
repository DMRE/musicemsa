<? session_start();
    $_SESSION["4"]='class="is-active"';
	include 'php/connect.php';
	$query ="SELECT * FROM `DATA-PAGES` WHERE ID = 10";
	$meta = mysqli_fetch_array(mysqli_query($link,$query),MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html class="no-js">
   <head>
      <title><? echo $meta['Titulo'] ?></title>
      <meta name="description" content="<? echo $meta['Descripcion'] ?>">
      <meta name="Keywords" content="<? echo $meta['Palabras_Clave'] ?>" />
      <? include 'php/config.html';?>
   </head>
   <body>
   <? include 'header.php'; ?> 
   <div class="main-containter">
         <div class="container">
         </div>
         <div class="container body-pannel-white-full">
           <div class="relleno"></div>
            <div class="row text-center margin-body-pannel-full">
                <img class="img-responsive img-center" src="assets/images/alaemus.png" style="max-height:250px" /><br><br>
                <div class="relleno"></div>
                <div class="embed-responsive embed-responsive-16by9 video-shadow"><iframe class="embed-responsive-item" src="//www.youtube.com/embed/fI2_Wg3WUEE"></iframe></div><div class="relleno"></div>
                <p class="texto-1">Es la Asociación Latinoamericana de Escuelas de Música. Su objetivo fundamental es lograr el intercambio de materiales pedagógicos, docentes y alumnos de las más importantes escuelas de música de Latinoamérica, así como promover el  conocimiento y dominio  de nuestros patrimonios  culturales.<br>
Como parte de sus estatutos solo 8 escuelas por país pueden conformar sus integrantes y dichas instituciones deben mantener un estándar de calidad, tanto en sus programas educativos, como en su cuerpo académico.
 <br><br>
ALAEMUS  también es el organizador, cada año, del CLAEM (Congreso Latinoamericano de Escuelas de Música) en los que se ofrecen cursos, conferencias,  intercambio de experiencias entre los directivos de las escuelas, programas, talleres y formación de ensambles bajo la batuta de  maestros  y artistas prestigiados de diferentes partes de América. En la clausura del  CLAEM, se  otorgan becas de estudio a los alumnos mas destacados que asistieron a las talleres.
 <br><br>
A partir de abril del 2016 la EMSA se integra a esta red de escuelas. La 1ra en Jalisco.
              <div class="relleno"></div>
         </div>
      </div>
    <? include 'pie.html'; ?>
   </body>
</html>