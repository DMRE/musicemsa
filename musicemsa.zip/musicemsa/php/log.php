<?php

	session_start();
 	require_once 'connect.php';
	$user_email = trim($_POST['user_email']);
	$user_password = trim($_POST['password']);
	$query = "SELECT * FROM `User-s` WHERE Usuario = '".$user_email."' AND Contraseña = '".$user_password."'";
	
	//$password = md5($user_password);
	
	$connection = mysqli_query($link,$query);
	if(mysqli_num_rows($connection)==1){
		$row = mysqli_fetch_array($connection, MYSQLI_ASSOC);
		$_SESSION['loggedIn'] = true;
		$_SESSION['ID'] = $row['ID'];
		$_SESSION['user'] = $row['Usuario'];
		$_SESSION['name'] = $row['Nombre'];
		$_SESSION['img'] = $row['IMG'];
		$_SESSION['start'] = time();
		$_SESSION['expire'] = time() + (30 * 60);
		echo "loggedIn";
	}
	else{
		echo "Error Login";
		}
	
?>