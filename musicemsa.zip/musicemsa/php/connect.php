<?
	header("Content-Type: text/html;charset=utf-8");
		
	$host = 'localhost';
	$user = '1147967';
	$pass = 'Mixbox360';
	$db   = '1147967';
	$link = mysqli_connect($host,$user,$pass,$db) or die ('No se ha podido conectar a la base de datos: ' - mysql_error());
	$acentos = $link->query("SET NAMES 'utf8'");

?>