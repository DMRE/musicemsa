<?php
function checkLog(){
	session_start();
	if(($_SESSION['loggedIn'] == true && $_SESSION['start'] < $_SESSION['expire'])){
		$_SESSION['expire'] = time() + (30 * 60);
		return true;	
	}
	else{
		session_destroy();
		return false;
	}
}

function redirectToIf($bool,$ifTrue,$ifFalse){
	
	if($bool==true && isset($ifTrue)){
		header('Location: http://musicemsa.xp3.biz/'.$ifTrue);
	}
	else{
		if($bool==false && isset($ifFalse)){
		header('Location: http://musicemsa.xp3.biz/'.$ifFalse);
		}
		else{}
	}
}

?>