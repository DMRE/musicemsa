<?PHP 
	$name = $_POST["name"];
	$lastName = $_POST["lastName"];
	$email = $_POST["email"];
	$phone = $_POST["phone"];
	$message = $_POST["message"];
	$from = $_POST["from"];
	
	$subject ="Escuela de Música & Artes";
	$messageToMail = "Hola "+$name+" nos pondremos en contacto lo mas pronto posible contigo";
	$email_from = "info@musicemsa.xp3.biz";
	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	$headers .= 'From: <webmaster@musicemsa.xp3.biz>' . "\r\n";

	if(mail($email,$subject,$messageToMail,$headers)){
	include 'connect.php';
	$query = "INSERT INTO `Interesados` (`ID`, `Nombre`, `Apellidos`, `Correo`, `Telefono`, `mensaje`, `URL-Proveniente`, `¿Nuevo?`) VALUES (NULL, '$name', '$lastName', '$email', '$phone', '$message', '$from', '1')";
	if(mysqli_query($link,$query))
		echo true;
	else
		echo false;
	}
	else
		echo false;
?> 