<?  session_start();
    $_SESSION["3"]='class="is-active"';	
	include 'php/connect.php';
	$query ="SELECT * FROM `DATA-PAGES` WHERE ID = 6";
	$meta = mysqli_fetch_array(mysqli_query($link,$query),MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html class="no-js">
<!-- Parte logica para redirecciónar en caso de que sea otra pagina -->
   <head>
      <title><? echo $meta['Titulo'] ?></title>
      <meta name="description" content="<? echo $meta['Descripcion'] ?>">
      <meta name="Keywords" content="<? echo $meta['Palabras_Clave'] ?>" />
      <? include 'php/config.html';?>
   </head>
   <body>
   <? include 'header.php';?>
   <div class="main-containter">
         <div id="fixed-background-color"></div>
         <img id="fixed-background" src="http://musicemsa.xp3.biz/assets/images/instruments/background.jpg" />
         <div class="container">
            <div class="row">
               <div class="relleno"></div>
               <h1 class="text-center" style="color:white; font-weight:lighter; font-size:70px">Preparatoria para Universidades</h1>
               <div class="relleno"></div>
               
            </div>
         </div>
         <div class="container body-pannel-white-full">
            <div class="row">
            <div class="relleno"></div>
            <p class="texto-1">
              <? $row = mysqli_fetch_array(mysqli_query($link,'SELECT * FROM `Inicio-texto` WHERE ID = 1'),MYSQLI_ASSOC);
			  	echo $row['text-1'];
			   ?> 
             </p>
               </div>
              <!--TERMINA-->
              <div class="relleno"></div>
              <br>
         </div>
      </div>
    <? include 'pie.html'; ?>
   </body>
</html>