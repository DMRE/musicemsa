<? session_start();
   $_SESSION["4"]='class="is-active"';
   include 'php/connect.php';
   $query ="SELECT * FROM `DATA-PAGES` WHERE ID = 11";
   $meta = mysqli_fetch_array(mysqli_query($link,$query),MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html class="no-js">
   <head>
      <title><? echo $meta['Titulo'] ?></title>
      <meta name="description" content="<? echo $meta['Descripcion'] ?>">
      <meta name="Keywords" content="<? echo $meta['Palabras_Clave'] ?>" />
      <? include 'php/config.html';?>
   </head>
   <body>
   <?   include 'header.php'; ?> 
   <div class="main-containter">
         <div class="container">
         </div>
         <div class="container body-pannel-white-full">
           <div class="relleno"></div>
            <div class="row text-center margin-body-pannel-full">
                <img class="img-responsive img-center" src="assets/images/rockschool.png" /><br><br>
                <div class="relleno"></div>
                <p class="texto-1">Rockschool es el consejo británico examinador para músicos de rock y pop número 1 en el mundo desde hace dos décadas.<br><br>
                A través de dicha institución,  cualquier músico aficionado o profesional, estudiante o maestro, principiante o avanzado puede optar por realizar un examen de certificación para obtener un diploma que avale internacionalmente su nivel.
Rockschool Ltd. es el único consejo examinador a nivel mundial que se especializa en certificar a músicos que disfrutan del Rock y el Pop.  
 <br><br>
Los certificados son acreditados por el gobierno británico  en los principales instrumentos de rock y pop en diferentes niveles, desde básico hasta licenciatura y lo pueden aplicar niños, jóvenes y adultos.
Tambien cuenta con  la certificación de Teatro Musical.
Estos exámenes se llevan a cabo durante todo el año alrededor del mundo en los 5 continentes.  En México se aplican desde 2008 en dos épocas al año, en nuestros centros autorizados de certificación vía las instituciones afiliadas en distintas ciudades de la república.  <br>
En Jalisco la EMSA es la 1ra.<br>
Para mayores informes visite <a href="www.rockschool.mx">www.rockschool.mx</a>
              <div class="relleno"></div>
         </div>
      </div>
    <? include 'pie.html'; ?>
   </body>
</html>