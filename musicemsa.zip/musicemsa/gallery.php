<?php 
	$type = $_POST["tipo"]; //Obtenemos el tipo de dato que queremos mostrar 
	
	function downloadData($tipo){
		include 'connect.php';
		$query = "SELECT * FROM ".$tipo; //Creamos la Query
		if(!$result = mysqli_query($link,$query)) die();//verificamos que la conexion haya sido correcta, si no con "die();" terminaremos de ejecutar este archivo php
		$rawdata = array(); //creamos un array
		$i=0;
		while($row = mysqli_fetch_array($result)){
			$rawdata[$i]= $row;
			$i++;
		}
		mysqli_close($link);
		return $rawdata;
	}
	
	$myarray = downloadData($type);
	echo json_encode($myarray);
 ?>