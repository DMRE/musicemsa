<? session_start();
   $_SESSION["4"]='class="is-active"';
   include 'php/connect.php';
   $query ="SELECT * FROM `DATA-PAGES` WHERE ID = 7";
   $meta = mysqli_fetch_array(mysqli_query($link,$query),MYSQLI_ASSOC);
   		?>
<!DOCTYPE html>
<html class="no-js">
   <head>
      <title><? echo $meta['Titulo'] ?></title>
      <meta name="description" content="<? echo $meta['Descripcion'] ?>">
      <meta name="Keywords" content="<? echo $meta['Palabras_Clave'] ?>" />
      <? include 'php/config.html';?>
   </head>
   <body>
   <? include 'header.php'; ?>
   <div class="main-containter">
     <div class="container body-pannel-white-full">
       <div class="relleno"></div>
            <div class="row text-center margin-body-pannel-full">
            <div class="col-md-6">
                <h2>Nuestra Misión</h2><br><br>
                <p class="texto-1">Dar una formación integral con una alta calidad académica y humana, para todos sus estudiantes interesados ya sea como instrumentista, cantante, maestro o artista. </p>
            </div>
            <div class="col-md-6">
                <h2>Nuestra Visión</h2><br><br>
                <p class="texto-1">Convertirse en una  de las mejores Escuelas de Música  Mexicanas, con proyección internacional en cada uno de los niveles que imparte, en cuanto a la calidad educativa y de formación integral, como seres humanos, profesionales y exitosos de dónde salgan futuros intérpretes, maestros  y artistas representantes del país. Y ser un punto de encuentro y de intercambio con escuelas de música y universidades reconocidas a nivel mundial. </p>
            </div>
            <div class="relleno"></div>
            <div class="col-md-12">
              <h2>Historia</h2><br><br>
                <p class="texto-1">La  EMSA es un centro especializado en educación musical para niños y jóvenes que abrió sus puertas el 1 septiembre de 2011. El inicio de este proyecto estuvo a cargo de Paula Leitao, Tettey Oseguera y la Musicóloga Ileana Güeche Hernández, quién tiene a su cargo la dirección de la Escuela desde entonces.<br><br>
Los instrumentos con los que abrió en 2011 fueron solo piano y violín, utilizando dos tipos de metodologías, en el caso de niños pequeños, el método Suzuki y a partir de los 8 o 9 años el sistema tradicional de enseñanza empleado en los conservatorios. Debido a la demanda se abrieron, 6 meses después,  otros instrumentos como Violoncello, Guitarra, canto infantil y juvenil, con mucho éxito. En la actualidad a estas academias se le han sumado bateria y flauta transversal. 
 <br><br>
Independientemente de las clases dirigidas hacia los niños, la EMSA  comenzó también con un programa dirigido a los profesionales y maestros de música que deseaban profundizar y capacitarse en varias áreas, por medio de talleres y cursos.  En el primer año se abrieron los cursos de Perfeccionamiento del Solfeo y Armonía y el Curso de Técnica de Dirección Coral. En 2012-13 se impartió el curso de técnicas elementales de la dirección orquestal-coral. En la actualidad  contamos con una variada paleta de cursos tratando de estar a la vanguardia en cuanto a las necesidades de la comunidad. <br><br>
 
Desde el inicio de la EMSA hasta hoy se han realizado un buen número de conciertos a cargo de alumnos, maestros y artistas invitados. Siempre hemos estado abiertos hacer convenios de colaboración con otras instituciones y artistas. 
En Julio del 2012  los alumnos de canto infantil fueron invitados   a colaborar como coro de apoyo   del  grupo de rock tapatio,  Thecnicolor Fabrics, en el festival 212 RMX auspiciado por Imagen Radio, frente a mas de 5000 espectadores. Hemos trabajado también con la OSIJU en el programa De película, entre otras.  
 <br><br>
Junto al Instituto Alpes San Javier desde el 2015 
somos organizadores del Encuentro de las Artes, un evento dirigido a fomenter el talento infantil  en diferentes áreas como la pintura, el teatro y por supuesto nuestro fuerte, la música. 
 <br><br>
A muy poco de fundada la EMSA, nuestro programa personalizado de preparación pre- universitaria ha dado frutos, al ser aceptados ya varios estudiantes a Berklee College en Boston,E.U.,  la Escuela de música popular mas famosa  del mundo, la UNAM y la UDG.  
 <br><br>
En junio del 2014 se iniciaron los Vocal Camp   bajo la dirección de la cantante, arreglista y  compositora Sofia Rei, docente de Berklee College of Music. 
 <br><br>
Orgullosamente nuestros logros mas recientes han sido el ingresar a la Asociación Latinoamerica de Escuelas de Música (ALAEMUS) y entablar  contacto con la ABRSM (Royal Academy of Music) y la Rockschool, organismos con los cuales pretendemos preparar a los alumnos que deseen tener una certificación con validez europea en la rama de la música clásica y popular por medio de examenes que les permitan ir pasando los diversos grados o niveles que contienen con los cuales respalden su crecimiento como músicos.  
 </p>
            </div>
            <div class="relleno"></div>
         </div>
      </div>
    <? include 'pie.html'; ?>
   </body>
</html>