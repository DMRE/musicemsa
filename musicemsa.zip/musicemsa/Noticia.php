<? session_start();
   $_SESSION["2"]='class="is-active"';
   require_once 'php/connect.php';
   $idNoticia = $_GET["id"];
   if(isset($idNoticia)){
     if(is_numeric($idNoticia)){
		$sql_query = "SELECT * FROM Noticias WHERE ID_N = '$idNoticia'";
		$result=mysqli_query($link,$sql_query);
		$numRows = mysqli_num_rows($result);
			if($numRows == 0){
				echo '<script type="text/javascript">
         		window.location.assign("Noticias");
         		</script>';
				}
	  }
      else{
            echo '<script type="text/javascript">
         	window.location.assign("Noticias");
         	</script>';
           }
      }
      else{
         	echo '<script type="text/javascript">
         	window.location.assign("Noticias");
         	</script>';
      }
	$row=mysqli_fetch_array($result,MYSQLI_ASSOC); ?>

<!DOCTYPE html>
<html class="no-js">
   <head>
      <title>EMSA | <? echo $row["Titulo"] ?></title>
      <meta name="description" content="<? echo $row['Descripcion'] ?>">
      <meta name="Keywords" content="<? echo $row['Palabras_Clave'] ?>" />
      <? include 'php/config.html'; ?>
   </head>
   <body>
   	  <? include 'header.php'; ?>
               <div class="container notice">
                  <div class="panel panel-default body-pannel">
                    <div class="panel-body">
                  		<div class="col-md-8 notice-left-margin">
                        <h1 class="text-left" style="color:white"><? echo $row['Titulo']; ?></h1>
                      	<br>
                      	<p class="small" style="color:white"><? echo $row['Fecha']?></p>
                        <p style="color:white"><? echo $row['Texto']; ?></p>
                        <? echo'<img class="img-responsive" src="../../../../assets/images/notices/'.$row["img"].'">'?>
                        <br>
                        <p style="color:white"><? echo $row['Texto1']; ?></p>
                  	</div>
                  		<div class="col-md-4">
                    		<div class="panel panel-default notice-right-margin">
                      			<div class="panel-body" >
                                    <form>
                                      <h4 class="text-center">Inscribete</h4>
                                      <fieldset class="form-group">
                                        <label for="exampleInputEmail1">Nombre</label>
                                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Escribe tu nombre">
                                      </fieldset>
                                      <fieldset class="form-group">
                                        <label for="exampleInputEmail1">Número de Telefono</label>
                                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Escribe tu número Telefonico">
                                      </fieldset>
                                      <fieldset class="form-group">
                                        <label for="exampleInputPassword1">Correo Electronico</label>
                                        <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Escribe tu Correo Electronico">
                                         </fieldset>
                        <button type="submit" class="btn btn-primary center-block">Solicitar Información</button>     
                    </div>
                 </div>
                </div>
              </div>
  			</div>
      <? include 'pie.html'; ?>
   </body>
</html>

<style>
      	.notice:before{
  			content: "";
			position: fixed;
			top: 0;
			bottom: 0;
			left: -5;
			right: 0;
			z-index: -1;
			display: block;
			background-image: url("<? echo '../../../../assets/images/notices/'.$row['img']; ?>");  
			width: 110%;
		    height: 110%;  
		    -webkit-filter: blur(9px);
		    -moz-filter: blur(9px);
		    -o-filter: blur(9px);
		    -ms-filter: blur(9px);
		    filter: blur(9px);
		}
      </style>