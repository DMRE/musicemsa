<!DOCTYPE html>
<html class="no-js">
<!-- Parte logica para redirecciónar en caso de que sea otra pagina -->
      <?
         session_start();
         $_SESSION["4"]='class="is-active"';
		 include 'php/connect.php';
         $id = $_GET["id"];
         if(isset($id)){
         	if(is_numeric($id)){
				$sql_query = "SELECT * FROM `Cuerpo-Academico` WHERE `ID` = '$id'";
				$result=mysqli_query($link,$sql_query);
				$numRows = mysqli_num_rows($result);
				if($numRows == 0){
					echo '<script type="text/javascript">
         			window.location.assign("cuerpoAcademico.php");
         			</script>';
					}
				}
         	else{
         		echo '<script type="text/javascript">
         		window.location.assign("cuerpoAcademico.php");
         		</script>';
         		}
         	}
         else{
         		echo '<script type="text/javascript">
         		window.location.assign("cuerpoAcademico.php");
         		</script>';
         	}
		$row=mysqli_fetch_array($result,MYSQLI_ASSOC);
		$query ="SELECT * FROM `DATA-PAGES` WHERE ID = 1";
	    $meta = mysqli_fetch_array(mysqli_query($link,$query),MYSQLI_ASSOC);
       ?>
   <head>
      <title><? echo $meta['Titulo'] ?></title>
      <meta name="description" content="<? echo $meta['Descripcion'] ?>">
      <meta name="Keywords" content="<? echo $meta['Palabras_Clave'] ?>" />
      <? include 'php/config.html';?>
   </head>
   <body>
   <? include 'header.php'; ?> 
      <div class="container">
  <div class="body-pannel-white-full">
    <div class="relleno"></div>
    <div class="row">
      <img class="img-curriculum" src="assets/images/cuerpo-academico/<? echo $row["IMG"] ?>"/>
    </div>
    <br>
    <div class="row">
      <h1 class="text-center"><? echo $row["Nombre"].' '.$row["Apellido"].'<br><small>'.$row["Puesto"].'</small>' ?></h1>
    </div>
    <br>
    <div class="row texto-1">
      <p> <? echo $row["Curriculum"] ?> </p>
    </div>
    <div class="relleno"></div>
  </div>
</div>     
      <? include 'pie.html'; ?>
   </body>
</html>