<!DOCTYPE html>
<html class="no-js">
    <head>
        <meta charset="utf-8">
        <title>EMSA | Galería</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<? include 'php/config.html'; ?>


    </head>
    <body>
	<?
		session_start();
		$_SESSION["5"]='class="is-active"';
    	include 'header.php';
	?>
	<div class="page-heading text-center">
	  <div class="container zoomIn animated">
		<h1 class="page-title">Galeria</h1>
			
		</div>

	</div>

	<div class="main-container text-center body-pannel-white-full">
    
     
            
    	<div class="container gallery fadeIn animated">
          <div class="col-md-12">
        <img id="Fotos" class="img-button" src="http://musicemsa.xp3.biz/assets/images/icons/camera_photo.png" />
        <img id="Videos" class="img-button" src="http://musicemsa.xp3.biz/assets/images/icons/video_camera.png" />
        </div>
			</div>
    <div class="relleno"></div>
			<div id="img-here" class="row"> 
            	
			</div>
		</div>
        
	</div> <!-- /.main-container  -->
	<? include 'pie.html'; ?>
        <script type="text/javascript">
		
		var showData = function($tipo){
			$('#img-here').empty();
			if(objPhoto!=null && $tipo == "Fotos"){
				$.each(objPhoto,function(index,value){
				$('#img-here').append("<a href='assets/images/gallery/"+ value.Nombre +"' class='col-md-3 col-sm-4 gallery-item lightbox'><img src='assets/images/gallery/thumb/" + value.Nombre + "' alt=''><span class='on-hover'><span class='hover-caption'>Ver Imagen</span></span></a>");
							});
			}
			else{
				if(objVideo!=null && $tipo == "Videos"){
					$.each(objVideo,function(index,value){
						$('#img-here').append('<div class="embed-responsive embed-responsive-16by9 video-shadow"><iframe class="embed-responsive-item" src="//www.youtube.com/embed/' + value.URL + '"></iframe></div><div class="relleno"></div>');
							});
					}
				else{
					$.ajax({
				url: "php/gallery.php",
				method: "POST",
				data: { tipo: $tipo }
					})
				.done(function(data) {
						if($tipo == "Fotos"){
						objPhoto = JSON.parse(data);
						$.each(objPhoto,function(index,value){
							$('#img-here').append("<a href='assets/images/gallery/"+ value.Nombre +"' class='col-md-3 col-sm-4 gallery-item lightbox'><img src='assets/images/gallery/thumb/" + value.Nombre + "' alt=''><span class='on-hover'><span class='hover-caption'>Ver Imagen</span></span></a>");
							});
						}
						else{
						objVideo = JSON.parse(data);
						$.each(objVideo,function(index,value){
							$('#img-here').append('<div class="embed-responsive embed-responsive-16by9 video-shadow"><iframe class="embed-responsive-item" src="//www.youtube.com/embed/' + value.URL + '"></iframe></div><div class="relleno"></div>');
							});
						}
				})
				.fail(function(data){
						console.log("Ha fallado la conexion, Por favor intentelo mas tarde.");
					});
					}
				}
		},
		target = "", objPhoto=null, objVideo=null;
				
		$(document).ready(function(){
			});
			
		$( document.body ).on( 'click', '#Fotos, #Videos', function( event ) {
			var $target = $( event.currentTarget );
			$('.img-button').animate({height:100},1000);
			if($target.attr("id") == "Fotos" && target != "Fotos"){
				target="Fotos";
				showData(target);
			}
			else {
				if($target.attr("id") == "Videos" && target != "Videos"){
				target="Videos";
				showData(target);
					}
				}
			
			$target.closest( '.btn-group' ).find( '[data-bind="label"]' ).text( $target.text() ).end().children( '.dropdown-toggle' ).dropdown( 'toggle' );
			return false;
		});
   
        </script>
        
    </body>
</html>
