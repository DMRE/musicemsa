<!DOCTYPE html>
<html class="no-js">
    <head>
        <meta charset="utf-8">
        <title>EMSA | Contacto</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<? include 'php/config.html';?>
    </head>
    <body>
    <!-- NAVBAR
    ================================================== -->
	<?
		session_start();
		$_SESSION["6"]='class="is-active"';
    	include 'header.php';
	?>
	<div class="page-heading text-center">
		<div class="container zoomIn animated">
			<h1 class="page-title">Contactanos</h1>
			<p class="page-description"></p>
		</div>
	</div>
	<div class="main-container fadeIn animated">
		<div class="container">
			<div class="row">
				<div class="col-md-7 col-sm-12 col-form">
					<h2 class="title-style-2">Formulario de Contacto</h2>
					<form action="php/mail.php" class="contact-form ajax-form">
						<div class="row">
							<div class="form-group col-md-6">
	                            <input type="text" name="name" class="form-control" placeholder="Name*" required>
	                        </div>
	                         <div class="form-group col-md-6">
	                            <input type="email" name="email" class="form-control" placeholder="E-mail*" required>
	                        </div>
						</div>
                        <div class="form-group">
                            <textarea name="message" rows="5" class="form-control" placeholder="Message*" required></textarea>
                        </div>
                        <div class="form-group alerts">
                        	<div class="alert alert-success" role="alert">
							</div>
							<div class="alert alert-danger" role="alert">
							</div>
                        </div>
                         <div class="form-group">
                            <button type="submit" class="btn btn-primary pull-right">Enviar Mensaje</button>
                        </div>
                        <div class="clearfix"></div>
					</form>
				</div>
				<div class="col-md-4 col-md-offset-1 col-contact">
					<h2 class="title-style-2"> EMSA </h2>
					<p>Nos encontramos dentro de las instalaciones del Instituto Alpes San Javier.</p>
					<div class="contact-items">
						<ul class="list-unstyled contact-items-list">
							<li class="contact-item"> <span class="contact-icon"> <i class="fa fa-facebook"></i></span> <a href="https://www.facebook.com/EMSAEscuelademusica/">EMSA</a></li>
							<li class="contact-item"> <span class="contact-icon"> <i class="fa fa-map-marker"></i></span> Paseo del Eden 2459, Colinas de San Javier, 44660 Guadalajara, Jal.</li>
							<li class="contact-item"> <span class="contact-icon"> <i class="fa fa-phone"></i></span> +52 36-42-00-18</li>
							<li class="contact-item"> <span class="contact-icon"> <i class="fa fa-envelope"></i></span> contacto@musicemsa.com</li>
						</ul>
					</div>
				</div>
			</div> <!-- /.row -->
		</div>
	</div>
	<div id="contact-map" class="contact-map">
	</div>
	<? include 'pie.html'; ?>
    </body>
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCNnmqiQ02hbNv-HW1-seinPGQ750BdpoQ&signed_in=true&language=es-mx&callback=initMap"></script>
   <script>
		function initMap() {
		  var school = {lat: 20.70649, lng: -103.40312};
		  var map = new google.maps.Map(document.getElementById('contact-map'), {
			scaleControl: true,
			center: school,
			zoom: 15
		  });
		  var infowindow = new google.maps.InfoWindow;
		  infowindow.setContent('<b>EMSA</b>');
		  var marker = new google.maps.Marker({map: map, position: school});
		  marker.addListener('click', function() {
			infowindow.open(map, marker);
		  });
		}
    </script>
</html>
