<?php
	require_once 'php/functions.php';
	redirectToIf(checkLog(),'admin/welcome.php',null);
?>	
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
      <title>Iniciar Sesión | EMSA</title>
      <? include 'php/config.html';?>
   </head>
   <body>
      <div class="container background-div" id="base" >
         <div id="login-Animate" class="login">
            <h2 class="text-center">Iniciar Sesión</h2>
            <form method="post" role="form" id="login-form" name="login-form" method="post">
                <div id="error1" class="alert alert-warning" role="alert">
                Llena los campos faltantes.
                </div>
                <div id="error2" class="alert alert-danger" role="alert">
                Usuario o Contraseña incorrectos.
                </div>
               <div class="form-group">
                  <label for="email">Correo:</label>
                  <input type="email" class="form-control" id="user_email" placeholder="Ingresa el Correo Electronico" name="user_email" >
               </div>
               <div class="form-group">
                  <label for="pwd">Contraseña:</label>
                  <input type="password" class="form-control" id="password" placeholder="Ingresa la Contraseña" name="password">
               </div>
               <button type="submit" class="btn btn-default" name="btn-login" id="btn-login">
      			<span class="glyphicon glyphicon-log-in"></span> &nbsp; Iniciar Sesión           
                </button>
                </form>
         </div>
      </div>
   </body>
</html>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.9.1/jquery-ui.min.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
		$('#error1 #error2').hide();
		$('#login-form').submit(function(){
			$('#error1').hide();
			$('#error2').hide();
			if(validator($('#user_email').val(),$('#password').val()) == false){
				$('#error1').show();
				}
			else{
				login($('#login-form'));
				}
			return false;
			});
		});
	
	/* Enviar Formulario */
	function validator(correo,password){
		if(correo == "" || password == "")
			return false;
		else
			return true;
	}
	
	function login($data){
		$.ajax({
			type: "POST",
			url : "php/log.php",
			data: $data.serialize(),
			success:function(data){
				if(data=="loggedIn"){
					window.location.assign("admin/welcome.php");
					}
				else{
					$('#login-Animate').effect('bounce',{times:4},800);
					$('#base').animate({backgroundColor:'#ff3333'},50);
					$('#base').animate({backgroundColor:'#f2f2f2'},750);
					$('#error2').show();
					}
				},
			fail:function(){
				console.log('fallo la conexion');
				}
			});
		return false;
		}
</script>